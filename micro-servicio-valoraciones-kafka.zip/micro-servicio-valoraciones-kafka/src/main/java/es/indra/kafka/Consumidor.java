package es.indra.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class Consumidor {
	
	// si escucho de varios topics: topics = {"topic1", "topic2", "topic3"}
	@KafkaListener(topics = "indra-cluster")
	public void recibirComentario(String comentario) {
		System.out.println("************************************");
		System.out.println("Comentario recibido: " + comentario);
		System.out.println("************************************");
	}

}
