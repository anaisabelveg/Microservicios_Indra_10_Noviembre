package es.indra.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class Productor {

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	public void enviarComentario(String comentario) {
		kafkaTemplate.send("indra-cluster", comentario);
	}
}
