INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('juan', '$2a$10$beYHSn39mT0/zp5eEIfCcOyQ4dcXverGHm2fA2ShwPHji8nNmp.8.', 1, 'Juan', 'Lopez', 'juan@gmail.com');
INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('admin', '$2a$10$.tO5UWRPWTm3iO8MRbHNQeWSXrVNReb//q/h6wx1LHlrrlR7BQA7O', 1, 'Maria', 'Rodriguez', 'maria@gmail.com');

INSERT INTO roles (nombre) VALUES ('ROLE_USER');
INSERT INTO roles (nombre) VALUES ('ROLE_ADMIN');

INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (1,1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,2);