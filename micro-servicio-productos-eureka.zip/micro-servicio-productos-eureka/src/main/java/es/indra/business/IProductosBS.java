package es.indra.business;

import java.util.List;

import es.indra.entities.Producto;

public interface IProductosBS {
	
	List<Producto> consultarTodos();
	
	Producto buscarProducto(Long id);

}
