package es.indra.business;

import es.indra.models.Usuario;

public interface IUsuariosBS {
	
	public Usuario buscarUsuario(String username);

}
